package com/example/randomwelcome;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.Random;

public class RandomWelcome extends JavaPlugin implements Listener {
    private List<String> welcomeMessages;
    private final Random random = new Random();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        welcomeMessages = getConfig().getStringList("welcome-messages");

        if (welcomeMessages.isEmpty()) {
            getLogger().warning("Die Willkommensnachrichten-Liste ist leer! Bitte bearbeite die config.yml.");
        }

        Bukkit.getPluginManager().registerEvents(this, this);
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        if (welcomeMessages.isEmpty()) {
            return;
        }
        
        String message = welcomeMessages.get(random.nextInt(welcomeMessages.size()));
        event.getPlayer().sendMessage(ChatColor.translateAlternateColorCodes('&', message));
    }
}
